//ORDEN DE LOS ELEMENTOS DE UN ARRAY
const numeros=[20,3, 5, 7, 8, 100, 35, 8];
const apellidos=['Ojeda','Gorcía','García', 'Navarro', "Solís", "Luque"];

//1. Método TOSORTED (NO modifica el array original)
const apellidosToSort=apellidos.toSorted();
/*console.log("Apellidos original");
console.log(apellidos);
console.log("Apellidos toSorted");
console.log(apellidosToSort);*/

//2. Método SORT: Ordena alfabéticamente ascendente y SÍ modifica el original
//console.log("Apellidos después de SORT");
//apellidos.sort();

//3. Método reverse dar la vuelta al original
apellidos.sort().reverse();
//console.log(apellidos);

//ORDENACIÓN VALORES NUMÉRICOS
console.log(numeros);
//numeros.sort();
//console.log("Después de sort con los números");
//console.log(numeros);
numeros.sort(function(a,b){
    if(a>b){
        return 1;
    }else if(a<b){
        return -1;
    }else{
        return 0;
    }
});
console.log("Después de sort con los números con comparación");
console.log(numeros);
numeros.sort((a,b)=>a-b);

//ORDENAR ARRAYS BIDIMENSIONALES
const alumnos=[['María', 23], ['Antonio', 45], ["Carmen", 59]];
//Descendente
alumnos.sort((a,b)=>b[1]-a[1]);
console.table(alumnos);
//Ascendente
alumnos.sort((a,b)=>a[1]-b[1]);
console.table(alumnos);
