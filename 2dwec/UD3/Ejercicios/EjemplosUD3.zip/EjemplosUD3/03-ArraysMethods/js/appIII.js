//BUSCAR INFORMACIÓN EN UN ARRAY
const numeros=[20,3, 5, 7, 8, 100, 35, 200];
console.table(numeros);

//1º- Método FILTER que extrae elementos que cumplen una condición
const resultado=numeros.filter(numero=>numero>10);
//console.table(resultado);

//2º- Método FIND. Devuelve el primer elemento que cumple la condición (NO la posición)
const resultadoII=numeros.find(n=>n>50);
//console.log("El número mayor que 50 es: "+resultadoII);

//3º- Método SOME. Devuelve TRUE si algún elemento cumple la condición
const resultadoIII=numeros.some(n=>n>10);
console.log("Algún elemento es mayor que 10? "+resultadoIII);

//4º- Método EVERY. Devuelve TRUE si todos elementos cumple la condición
const resultadoIV=numeros.every(n=>n>10);
console.log("Todos son mayores que 10? "+resultadoIV);

//Método para concatenar dos arrays
const letras=['a','b'];
const todo=numeros.concat(letras);
console.table(todo);
const todoII=letras.concat(numeros);
console.table(todoII);
//Es lo mismo que el método SPREAD
const todoIII=[...letras,...numeros];
console.table(todoIII);