//PROPIEDADES Y MÉTODOS PRIVADOS

class Alumno{
    //Propiedades como privadas, tiene que estar fuera del constructor
    #nombre;
    #apellidos;
    #edad;
    constructor(nom, ape,edad){
        this.#nombre=nom;
        this.#apellidos=ape;
        this.#edad=edad;
    }
    //Métodos GET y SET
    get nombre(){
        return this.#nombre;
    }
    set nombre(nombre){
        //Controlamos la entrada de datos
        if(nombre != ""){
            this.#nombre = nombre;
        }else{
            //Generamos un error que será capturado por un try
            throw ("ERROR, el nombre no puede estar vacío.");
        }
    }
    get apellidos(){
        return this.#apellidos;
    }
    set apellidos(apellidos){
        //Controlamos la entrada de datos
        if(apellidos != ""){
            this.#apellidos = apellidos;
        }else{
            //Generamos un error que será capturado por un try
            throw ("ERROR, los apellidos no pueden estar vacíos.");
        }
    }
    get edad(){
        return this.#edad;
    }
    set edad(edad){
        if (edad>=18){
            this.#edad = edad;
        }else{
            throw ("ERROR, el alumno/a debe ser mayor de 18 años.");
        }
    }

    //Métodos
    //Métodos
    toString(){
        return `El nombre del alumno es ${this.#nombre} ${this.#apellidos} y tiene ${this.#edad} años.`
    }
}
try{
    const Alumno1 = new Alumno("María","Ojeda García",18);
    console.log(Alumno1.toString());
    console.log(Alumno1.nombre);//Debo usar GET (o SET)
    //console.log(Alumno1.#nombre);//Esto da error, porque es privada la propiedad
    //Alumno1.#apellidos = "Ojeda García";//ESto da error
    Alumno1.apellidos = "Luque García";//Con el método SET
    console.log(Alumno1.toString());
    Alumno1.edad = 3;//Salta el TRY
    
}catch(error){
    console.log(error);
    
}