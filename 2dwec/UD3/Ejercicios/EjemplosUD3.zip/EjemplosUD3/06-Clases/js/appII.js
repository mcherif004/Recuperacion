//Métodos getter y setter, se usan para asignar o extraer datos de las propiedades de un objeto.
//Importante que los métodos getter y setter no pueden tener el mismo nombre que la propiedad, lo que se suele hacer es comenzar el nombre de la propiedad con _

class Alumno{
    constructor(nom, ape,edad){
        this._nombre=nom;
        this._apellidos=ape;
        this._edad=edad;
        
    }
    //Para cada propiedad se debe definir un getter y un setter para trabajar con sus valores de forma encapsulada
    get nombre(){
        return this._nombre;
    }
    set nombre(nombre){
        //Controlamos la entrada de datos
        if(nombre != ""){
            this._nombre = nombre;
        }else{
            //Generamos un error que será capturado por un try
            throw ("ERROR, el nombre no puede estar vacío.");
        }
    }
    get apellidos(){
        return this._apellidos;
    }
    set apellidos(apellidos){
        //Controlamos la entrada de datos
        if(apellidos != ""){
            this._apellidos = apellidos;
        }else{
            //Generamos un error que será capturado por un try
            throw ("ERROR, los apellidos no pueden estar vacíos.");
        }
    }
    get edad(){
        return this._edad;
    }
    set edad(edad){
        if (edad>=18){
            this._edad = edad;
        }else{
            throw ("ERROR, el alumno/a debe ser mayor de 18 años.");
        }
    }

    //Métodos
    toString(){
        return `El nombre del alumno es ${this._nombre} ${this._apellidos} y tiene ${this._edad} años.`
    }
}
//Capturar errores
try{
    //Podemos crear alumnos a través del constructor
    const alumno1= new Alumno("María","Ojeda García",3);
    //Puedo crear alumnos sin valores en las propiedades, para usar GET y SET
    const alumno2= new Alumno();
    //En este caso, como las propiedades son públicas, si conozco el nombre de la propiedad puedo acceder directamente
    alumno2._nombre="Antonio";
    alumno2._apellidos="Ojeda Solís";
    
    alumno2._edad = 3;//Asigno el valor en la propiedad
    alumno1.edad = 19;//Asigno el valor con el set

     //Mostramos los datos
     console.log(alumno1.toString());
     console.log(alumno2.toString());

     console.log((alumno1._nombre));//Utilizando la propiedad directamente
     console.log(alumno1.nombre);//Utilizando el GET
     
}catch(error){
    console.log(error);
}
