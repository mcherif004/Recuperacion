"use strict";
//HERENCIA
class Electro{
    //Constructor
    constructor(nom,precio,color){
        this.nombre=nom;
        this.precio=precio;
        this.color=color;
        this.disponible=true;//Valor por defecto
    }
    //Métodos. Fuera del constructor
    toString(){
        return `El electrodoméstico es ${this.nombre}, el precio es ${this.precio} € y es de color ${this.color}. `;
    }
}

//Intanciar un objeto
const horno = new Electro("Horno",300, "Rosa");
console.log(horno.toString());

//Implementamos la herencia
class DispositivoElec extends Electro{
    //Creamos el contructor
    constructor(nom, precio, color, disco, ram){
        super(nom,precio,color);//Invocamos al construtor de la clase base
        this.disco=disco;
        this.ram=ram;
    }
    toString(){
        return `${super.toString()} El disco duro es de ${this.disco} y la memoria RAM es de ${this.ram}.`;
    }
}
//Instanciamos un objeto
const portatil = new DispositivoElec("HP",600,"Blanco","1 TB", "16 GB");
console.log(portatil.toString());