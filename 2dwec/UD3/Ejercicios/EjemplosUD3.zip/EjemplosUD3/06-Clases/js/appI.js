//CLASES
    class Electro{
        //Constructor
        constructor(nom,precio,color){
            this.nombre=nom;
            this.precio=precio;
            this.color=color;
            this.disponible=true;//Valor por defecto
        }
        //Métodos. Fuera del constructor
        toString(){
            return `El electrodoméstico es ${this.nombre}, el precio es ${this.precio} € y es de color ${this.color}`;
        }
        static mensaje(){//Los métodos static se llaman SIN instanciar la clase
            return("Creado un objeto electrodoméstico.")
        }
    }

    //Intanciación de objetos
    const frigo=new Electro("Frigorífico",200, "rojo");
    const horno=new Electro("Horno",300, "azul");

    //console.log(frigo,horno);
    console.log(frigo.toString());
    console.log(horno.toString());

    //Método STATIC
    console.log(Electro.mensaje());
    //console.log(frigo.mensaje());//Esto da error
    
    console.log(frigo.nombre);//Puedo acceder a esta propiedad porque es pública
    
    
    