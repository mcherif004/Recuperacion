//FORMAS DE CREAR UN CONJUNTO
const conjunto= new Set(); //Creamos un conjunto vacío
const conjuntoII = new Set([1,2,3,4]);//Le pasamos un array, que es un objeto iterable
const conjuntoIII = new Set([1,2,3,"3",4]);//JS elimina el duplicado
//console.log({conjunto});
//console.log({conjuntoII});
console.log({conjuntoIII});

//Conjunto a partir de un array existente
const aNum=[10,20,30];
const conjuntoIV= new Set(aNum);

//CÓMO RECORRER UN CONJUNTO
//1. Con FOR OF
/*console.log("Recorrido con FOR OF");
for (const elemento of conjuntoIV){
    console.log(elemento);
}
//2. Con FOR EACH
console.log("Recorrido con FOREACH");
conjuntoIV.forEach(elemento=>{
    console.log(elemento);
});*/
//AÑADIR ELEMENTOS CONJUNTO
//Método ADD
conjuntoIV.add(50);
console.log("Añado un elemento");
conjuntoIV.forEach(elemento=>{
    console.log(elemento);
});
//Podemos añadir más de un elemento a la vez
conjuntoIV.add(60).add(70).add(70);//Si está repetido no lo añade
console.log("Añado más de un elemento");
conjuntoIV.forEach((elemento)=>{
    console.log(elemento);
});
//ELIMINAR ELEMENTOS DE UN CONJUNTO
conjuntoIV.delete(60);
console.log({conjuntoIV});
console.log("Elimino un elemento");
conjuntoIV.forEach(elemento=>{
    console.log(elemento);
});
//OBTENER EL TAMAÑO DE UN CONJUNTO
console.log("Tamaño de un conjunto");
console.log(conjuntoIV.size);
//Localizar elementos dentro un conjunto
console.log(conjuntoIV.has(10));
//Eliminar todos los elementos del conjunto
conjuntoIV.clear();
console.log({conjuntoIV});



