//DEFINICIÓN DE OBJETOS LITERALES
const electro1={
    nombre:"Frigorífico",
    precio:300,
    color:"rojo"
}
const electro2={
    nombre:"Horno",
    precio:200,
    color:"azul"
}
console.log(electro1);
//Acceder a una propiedad, usando .
console.log(electro1.nombre);
//Acceder a una propiedad, usando la clave
console.log(electro1["nombre"]);

//Asignar valor usando .
electro1.color="negro";
console.log(electro1.color);

//Asignar valor usando la clave
electro2["color"]="rosita";
console.log(electro2["color"]);

//Agregamos propiedades, directamente asignándole un valor
electro1.disponible=true;
console.log(electro1);

//Eliminar propiedades
delete electro1.disponible;
console.log(electro1);

//DESTRUCTURING para asignar valores de las propiedades a variables
const {nombre,precio}=electro1;
console.log(`Propiedad nombre ${nombre}`);
console.log("Propiedad precio "+precio);

