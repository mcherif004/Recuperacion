const electro1={
    nombre:"Frigorífico",
    precio:300,
    color:"rojo",
    toString: function(){
        return `El electrodoméstico es ${this.nombre}, el precio es ${this.precio} y tiene el color ${this.color}`;
    }
}
//CREACIÓN DE OBJETOS A PARTIR DE OTROS, Método ASSING()
const medidas={
    peso:"60 kg",
    altura:"2m"
}
const electroCompleto=Object.assign(electro1,medidas);
//console.log(electroCompleto);

//Esto se puede hacer con el operador SPRED ...
const electroCompleto2={...electro1,...medidas};
//console.log(electroCompleto2);

//ACCESO A ELEMENTOS INDIVIDUALES DE UN OBJETO LITERAL
//Método KEYS: Devuelve un array con el nombre de las propiedades del objeto
console.log(Object.keys(electro1));

//Método VALUES: Devuelve array con los valores del objeto
console.log(Object.values(electro1));

//Método ENTRIES: Devuelve un array bidimensional con clave:valor
console.log(Object.entries(electro1));
