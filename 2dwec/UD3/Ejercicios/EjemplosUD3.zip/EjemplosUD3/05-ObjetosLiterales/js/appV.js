//OBJETOS ANIDADOS: objetos dentro de otros  objetos
const electro1={
    nombre:"Frigorífico",
    precio:300,
    color:"rojo",
    informacion:{
        medidas:{
            peso:"50kg",
            altura:"2m"
        },
        fabricacion:{
            pais:"España"
        }
    },
    toString: function(){
        return `El electrodoméstico es ${this.nombre}, el precio es ${this.precio} y tiene el color ${this.color}`;
    }
}
//Para acceder a las propiedades de los objetos anidados, usaremos el operador .
console.log(electro1.informacion);
console.log(electro1.informacion.medidas.peso);
console.log(electro1.informacion.fabricacion.pais);


