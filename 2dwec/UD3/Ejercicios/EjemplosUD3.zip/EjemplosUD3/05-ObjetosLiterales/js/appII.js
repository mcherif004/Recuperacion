//PROTEGER LA ESTRUCTURA Y EL CONTENIDO DE UN OBJETO LITERAL

const electro1={
    nombre:"Frigorífico",
    precio:300,
    color:"rojo"
}
//MÉTODO FREESE(): congelar
Object.freeze(electro1);//No permite modificar ni estructura ni contenido
//electro1.disponible=true;//No lo realiza
//electro1.color="negro";//No lo realiza


//Método ISFROZEN()
if (Object.isFrozen(electro1)){
    console.log("No puede alterarse el objeto");
}else{
    electro1.disponible=true;
    electro1.color="negro";
}
console.log({electro1});

//PROTEGER SOLO LA ESTRUCTURA DEL OBJETO LITERAL
const electro2={
    nombre:"Horno",
    precio:200,
    color:"azul"
}
//Método SEAL(): sellar, congela la estructura dejando que el contenido pueda cambiarse
Object.seal(electro2);
console.log({electro2});
electro2.disponible=true;
console.log({electro2});

//Método ISSEALED(): comprobar si el objeto está "sellado"
if (Object.isSealed(electro2)){
    console.log("No puede alterarse la estructura el objeto");
    electro2.color="negro";
}else{
    electro2.disponible=true;
}
console.log("Después del cambio");

console.log({electro2});