//DEFINICIÓN DE MÉTODOS 
const electro1={
    nombre:"Frigorífico",
    precio:300,
    color:"rojo",
    toString: function(){
        return `El electrodoméstico es ${this.nombre}, el precio es ${this.precio} y tiene el color ${this.color}`;
    },
    //toString2 hace lo mismo pero con =>
    toString2:()=>`El electrodoméstico es ${this.nombre}, el precio es ${this.precio} y tiene el color ${this.color}`
}
console.log(electro1.toString());


