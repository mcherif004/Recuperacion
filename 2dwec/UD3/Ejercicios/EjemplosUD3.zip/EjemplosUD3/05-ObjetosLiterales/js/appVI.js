//Creamos un array
const aAlumnos=[];

//Declaramos el construnctor
function Alumno(nom,ape,edad){
    this.nombre= nom;
    this.apellidos=ape;
    this.edad=edad;
    //método para mostrar la información de cada objeto
    this.toString=()=>{
        return `El nombre del alumno es ${this.nombre} ${this.apellidos} y tiene ${this.edad} años<br>`;
    }
}

//PEdimos los datos al usario hasta que cancela
const entradaDatos = ()=>{
    let nombre = prompt("Introduce el nombre del alumno (Cancelar->FIN)");
    while (nombre!=null){
        //Le pedimos el resto de datos
        let apellidos = prompt("Introduce los apelllidos del alumno");
        let edad = prompt("Introduce la edad del alumno");
        const alumno = new Alumno(nombre,apellidos,edad);
        aAlumnos.push(alumno);
        nombre = prompt("Introduce el nombre del alumno (Cancelar->FIN)");
    }
}
const salidaDatos = ()=>{
    aAlumnos.forEach(a=>{
        document.write(a.toString());
    })
}

entradaDatos();
salidaDatos();