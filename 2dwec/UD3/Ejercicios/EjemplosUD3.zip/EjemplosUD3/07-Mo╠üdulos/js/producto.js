const producto = (a,b) => a*b;
export default producto;