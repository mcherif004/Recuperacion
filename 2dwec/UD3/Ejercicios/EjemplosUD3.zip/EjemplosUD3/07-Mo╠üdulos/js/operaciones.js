export const add = (a,b) => a+b;
export const subst = (a,b) => a-b;


