//Necesitamos un servidor para ejecutar este código (Extesión Live Server, XAMP, MAMP, etc...)
import {add,subst} from './operaciones.js';
import producto from './producto.js';
import * as geometria from './geometria.js';

console.log(add(2,4));
console.log(subst(90,4));

console.log(producto(8,6));

console.log(geometria.areaCirculo(5));
console.log(geometria.areaRectangulo(6,7));



