export const areaCirculo = (radio) => Math.PI * radio * radio;
export const areaRectangulo = (base,altura) => base * altura;