"use strict"

//Patrón de diseño Singleton: se utiliza para asegurarnos que una clase solo tenga una instancia y proporcionar un punto de acceso global a instancia.

class Unica{
    constructor(nombre){
        //console.log(Unica.instancia);
        if (Unica.instancia){//Si ys tengo una instancia la devuelvo
            return Unica.instancia;
        }
        this.nombre = nombre;
        Unica.instancia = this;
    }
}
const instancia1 = new Unica("a");
console.log("Entre una instancia y otra.");
const instancia2 = new Unica("b");
console.log(instancia1);
console.log(instancia2);
console.log(instancia1 === instancia2); //Las dos son la misma instancia, con la misma dirección de memoria, etc..
