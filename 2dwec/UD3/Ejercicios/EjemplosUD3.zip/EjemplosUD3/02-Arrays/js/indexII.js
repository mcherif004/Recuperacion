//RECORRIDO DE UN ARRAY

const numeros = [1,2,3,,"cinco"];

//Vamos a declarar funciones para recorrer arrays de distintas formas

//RECORRIDO CON UN BUCLE FOR (TRADICIONAL)
//Sí recorre los vacíos
const recorrerFor=function(){//Expresión de función anónima
    console.log("For tradicional");
    for(let i=0;i<numeros.length;i++){
        //console.log(numeros[i]);
        console.log(`${i}.- ${numeros[i]}`);//Hacen lo mismo MÁS CORRECTA
    }
}
//recorrerFor();

//RECORRIDO CON BUCLE FOR IN
//Ignora los elementos vacíos del array
const recorrerForIn=()=>{
    console.log("For In");
    for (const i in numeros){
        console.log(`${i}.- ${numeros[i]}`)
    }
}
//recorrerForIn();

//RECORRIDO CON BUCLE FOR OF
//no necesitamos índice, accede a cada elemento
//Sí recorre los vacíos
const recorrerForOf=()=>{
    console.log("For OF");
    for (const elemento of numeros){
        console.log(`${elemento}`);
    }
}
//recorrerForOf();

//RECORRIDO CON FOREACH
//Ignora los elementos vacíos del array
const recorrerForEach=()=>{
    console.log("For each 1");
    numeros.forEach(elemento=>{
        console.log(`${elemento}`);
    });
    console.log("For each 2");
    numeros.forEach((elemento,i)=>{
        console.log(`${i}.- ${elemento}`);
    });
}
recorrerForEach();