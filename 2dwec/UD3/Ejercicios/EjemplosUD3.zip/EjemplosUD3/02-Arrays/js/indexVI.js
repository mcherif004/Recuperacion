//MÉTODO MAP()

let animales=["perro", "gato", "ratón", "león"];

//Recorremos el array con un FOREACH
let animalesForEach=animales.forEach(animal=>{
    return animal;
});//solo recorre los elementos. NO los devuelve
//console.log(animalesForEach); //UNDEFINED

let numeros = [1,2,3,4,5];
let doble = numeros.map(function(valor){//SÍ devuelve elemento
    return valor * 2;
});
console.table(numeros);
console.table(doble);

let raiz = doble.map(Math.sqrt);//Hace el cálculo por cada elemento
console.table(raiz);

//También puedo tener los índices
let numerosIndices= numeros.map(function(elemento,indice){
    return indice +": "+elemento;
});
console.table(numerosIndices);
