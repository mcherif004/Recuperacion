//arrays bidimensionales
let elect=[["Lavadora",100],['Microondas',200],['Horno',250]];
console.table(elect);
//console.log(elect[0][0]);
//console.log(elect[1][1]);

//RECORRER ARRAY N-DIMENSIONES
//1º Bucle FOR anidado
for (let f=0;f< elect.length;f++){
    for (let c=0;c< elect[f].length;c++){
        console.log(elect[f][c]);
    }
}
//2º FOREACH
elect.push(["Frigorifico",500,"A"]);
elect.forEach(elemento=>{
    console.log(elemento);//Comprobamos el elemento sobre el que se está aplicando la función, que es un array
    //Cada elemento a su vez es otro array
    elemento.forEach((elementoII,index)=>{
        if(index==0){
            cadena=`El nombre es ${elementoII}`;
        }else if(index==1){
            cadena+= `, su precio es ${elementoII}`;
        }else{ //No hace falta comprobar que consumo tiene algo, FOREACH no muestra undefined
            cadena+= ` y consumo es ${elementoII}`;
        }
    });
    console.log(cadena);
    
});

//AÑADIR UN ELEMENTO AL FINAL
elect.push(["Lavavajillas",300]);
console.table(elect);
//elect.push(["Frigorifico",500,"A"]);
console.table(elect);