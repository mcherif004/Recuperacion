//copias de arrays mediante el operador Spread

let numeros=[1,2,3,4,"cinco"];
let numerosBis=numeros;//Apunta a su dirección memoria - NO ES COPIA
numeros[5]=0;
numerosBis[6]=0;
console.table(numeros);
console.table(numerosBis);

//Hacer copia
//1º Forma: slice
//Devuelve un array que es una porción del array original o completo
let porcionNumeros= numeros.slice();
console.table(porcionNumeros);
porcionNumeros[0]="uno";
console.table(porcionNumeros);
console.table(numeros);
//2º Forma: ...(spread)
let numerosSpread=[...porcionNumeros];
console.table(numerosSpread);
let numerosSpreadII=["UNO","DOS",...numeros,"SEIS"];//Puedo incluirlo en cualquier elemento
console.table(numerosSpreadII);