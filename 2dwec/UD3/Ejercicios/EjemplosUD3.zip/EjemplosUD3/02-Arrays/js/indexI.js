//FORMAS DE DECLARAR UN ARRAY, DIMENSIÓN Y ACCESO AL ARRAY

//Forma tradicional (desuso)
const nombre=new Array(6);//Vacío con 6 elementos
const provincias=new Array('Córdoba',"Sevilla");

//Forma más común
const numeros=[1,2,3,4];
const letras=[];//array vacío
//console.log(nombre.length);
console.log(nombre.length);
nombre[nombre.length]="hola";//CRECER MI ARRAY
console.log(numeros);
console.table(numeros);
