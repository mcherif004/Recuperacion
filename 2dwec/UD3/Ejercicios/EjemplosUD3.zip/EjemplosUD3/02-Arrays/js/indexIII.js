//INSERTAR DATOS A UN ARRAY AL FINAL Y AL PPIO

//Declaramos un array mixto
const numeros=[1,2,3,4,"cinco"];
/*console.log(numeros.length);

//Insertamos elemento al final
//Forma1
numeros[numeros.length]=6;
console.table(numeros);

//Forma2 - Mediante PUSH
numeros.push(999);
console.table(numeros);
numeros.push(1);

console.table(numeros);
console.log(numeros.length);*/

//ELIMINAR ELEMENTOS DE UN ARRAY
//Forma1 - DELETE
console.table(numeros);
//delete numeros[2];//Borra el dato pero no elimina el elemento de memoria
//console.table(numeros);

//Forma2 - Elimino el último con POP
//console.log(numeros.pop());
//console.table(numeros);

//Forma3 - Eliminar el primero con SHIFT
//console.log(numeros.shift());
//console.table(numeros);

//Forma4 - Eliminar en una posición específica de forma correcta SPLICE
//Elimina desde la posición incial tantos elementos como indiquen el segundo argumento.
//console.table(numeros);
//console.log(numeros.splice(2,1));
//console.log(numeros.splice(2));//Solo un parámetro, me borra hasta el final
//console.table(numeros);

//SPLICE TAMBIÉN PERMITE AÑADIR ELEMENTOS EN MITAD DE UN ARRAY
//Insrta valor 77,88,99 a partir de la posición 2
//numeros.splice(2,0,77,88,99);
//console.table(numeros);
//sustituye dos elementos a partir del 2
numeros.splice(2,2,77,88,99);
console.table(numeros);