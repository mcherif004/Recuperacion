//DESTRUCTURING: esto nos va a permitir extraer datos de objetos o arrays y
//asignarlos a una variable.
let animales = ["perro","gato","ratón", "león"];

//Forma tradicional de extraer un elemento a una variable
let animalPerro=animales.at(0);
let animalGato=animales[1];
//console.log(animalPerro);
//console.log(animalGato);

//Extracción de elementos de un array mediante DESTRUCTURING
let [animalPerroII,animalGatoII]=animales;//almacena el primero y segundo elemento de animales
//console.log(animalPerroII);
//console.log(animalGatoII);
let [,,,animalUltimo]=animales;//puedo saltarme elementos
//console.log(animalUltimo);
let  [,...animalesII]=animales;//eztrae en un array desde el 2º elemento usando SPREAD
console.table(animalesII);

//USO DE DESTRUCTURING INTERCAMBIAR VALORES VARIABLES
let x = 2;
let y = 3;
console.log(x,y);
[x,y] = [y,x];//Evitamos el uso de variables intermedias
console.log(x,y);
