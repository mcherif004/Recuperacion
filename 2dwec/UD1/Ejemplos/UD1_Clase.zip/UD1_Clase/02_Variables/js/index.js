"use strict" //Obligatorio declarar variables y constantes

let nombre="María";
var apellido="Ojeda";
const edad=20;

console.log("Me llamo "+ nombre + " "+ apellido + " y tiene "+ edad + " años.");
console.log(`Me llamo ${nombre} ${apellido} y tengo ${edad} años.`);
