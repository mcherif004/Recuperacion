console.log("Hello Consola!");
alert("Hello usuario!");
console.log(prompt("Introduce un número",""));
console.log(confirm("¿Deseas continuar?"));