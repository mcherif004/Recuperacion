let nombre="María", numero;

//Mostrar el tipo de las variables
console.log(`El tipo de la variable ${nombre} es ${typeof nombre}`);
console.log(`El tipo de la variable ${numero} es ${typeof numero}`);

numero=23;
console.log(`El tipo de la variable ${numero} es ${typeof numero}`);
numero=true;
console.log(`El tipo de la variable ${numero} es ${typeof numero}`);
numero="23";
console.log(`El tipo de la variable ${numero} es ${typeof numero}`);
numero=numero+23;
console.log(`El tipo de la variable ${numero} es ${typeof numero}`);