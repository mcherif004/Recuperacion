const numero = 1;

if (numero == true){
    console.log("Los números son iguales ==");
} else {
    console.log("Los números NO son iguales ==");
}

if (numero === true){
    console.log("Los números son iguales ===");
}else {
    console.log("Los números NO son iguales ===");
}