<?php
include("db.php");

$jugador = $_POST['jugador'];
$oponente = $_POST['oponente'];
$ganador = $_POST['ganador'];

$sql = "INSERT INTO combates (jugador, oponente, ganador) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $jugador, $oponente, $ganador);
$stmt->execute();

echo "Combate guardado con éxito.";
?>
