<?php
include("db.php");

// Elimina el último combate insertado
$sql = "DELETE FROM combates ORDER BY id DESC LIMIT 1";
$conn->query($sql);

echo "Último combate eliminado.";
?>
