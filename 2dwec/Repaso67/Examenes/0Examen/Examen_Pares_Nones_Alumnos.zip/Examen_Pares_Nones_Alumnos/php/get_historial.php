<?php
include("db.php");

$sql = "SELECT fecha, ganador FROM combates ORDER BY fecha DESC";
$resultado = $conn->query($sql);

$historial = array();
while ($fila = $resultado->fetch_assoc()) {
    $historial[] = $fila;
}

echo json_encode($historial);
?>
