<?php
// Cabecera para que la respuesta sea en formato JSON y con codificación UTF-8
header("Content-type: application/json; charset=utf-8");

// Configuración conexión BBDD
$servidor = "localhost";
$usuario = "root";
$password = "";
$bbdd = "maria";

// Creo la conexión
$conexion = new mysqli($servidor, $usuario, $password, $bbdd);

// Comprobar si la conexion ha fallado
if ($conexion->connect_error) {
    die("La conexión ha fallado: " . $conexion->connect_error);
} else{
    // Consulta los alumnos y direccion
    if ($_SERVER['REQUEST_METHOD'] == 'GET') {
        $objeto = json_decode($_GET["objeto"]);
        if (!$objeto || !isset($objeto->tabla)){
            die(json_encode(["error" => "No se ha enviado el objeto", "datos recibidos" => $_GET["objeto"]]));
        }
    } elseif ($_SERVER["REQUEST_METHOD"] === "POST") {
        $jsonRecibido = file_get_contents("php://input");
        $objeto = json_decode($jsonRecibido, false);
    
        if (!$objeto || !isset($objeto->tabla)) {
            die(json_encode(["error" => "Faltan datos en la creación.", "datos_recibidos" => $jsonRecibido]));
        }
    
        if ($objeto->tabla === "alumnos" && isset($objeto->nombre) && isset($objeto->puntuacion)) {
            $sql = "INSERT INTO alumnos (alumno, puntuacion) VALUES (?, ?)";
            $stmt = $conexion->prepare($sql);
            $stmt->bind_param("si", $objeto->nombre, $objeto->puntuacion);
    
            if ($stmt->execute()) {
                echo json_encode(["success" => true, "idAlumno" => $stmt->insert_id]);
            } else {
                echo json_encode(["error" => "No se pudo crear el alumno."]);
            }
            $stmt->close();
        } else {
            echo json_encode(["error" => "Datos no válidos para la creación."]);
        }
    }else if ($_SERVER["REQUEST_METHOD"] === "PUT") {
        $jsonRecibido = file_get_contents("php://input");
        $datos = json_decode($jsonRecibido, false);
    
        if (!$datos && !isset($datos->tabla) && $datos->tabla !== "alumnos" && !isset($datos->idAlumno) && !isset($datos->nombre) || !isset($datos->puntuacion)) {
            die(json_encode(["error" => "Faltan datos para actualizar."]));
        }
    
        $sql = "UPDATE alumnos SET alumno = ?, puntuacion = ? WHERE idAlumno = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("sii", $datos->nombre, $datos->puntuacion, $datos->idAlumno);
    
        if ($stmt->execute()) {
            echo json_encode(["success" => true]);
        } else {
            echo json_encode(["error" => "Error en la actualización.", "mysql_error" => $stmt->error]);
        }
    
        $stmt->close();
    } elseif ($_SERVER["REQUEST_METHOD"] === "PATCH") {
        $jsonRecibido = file_get_contents("php://input");
        $datos = json_decode($jsonRecibido, false);
    
        if (!$datos && !isset($datos->tabla) && !isset($datos->idAlumno) || !isset($datos->puntuacion)) {
            die(json_encode(["error" => "Faltan datos para la actualización."]));
        }
    
        if ($datos->tabla === "alumnos") {
            $sql = "UPDATE alumnos SET puntuacion = ? WHERE idAlumno = ?";
            $stmt = $conexion->prepare($sql);
            $stmt->bind_param("ii", $datos->puntuacion, $datos->idAlumno);
    
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    echo json_encode(["success" => true]);
                } else {
                    echo json_encode(["error" => "No se encontró el alumno o la puntuación no cambió."]);
                }
            } else {
                echo json_encode(["error" => "Error en la consulta SQL.", "sql_error" => $stmt->error]);
            }
            $stmt->close();
        } else {
            echo json_encode(["error" => "Tabla no válida."]);
        }
    }
    

    // Comprobamos si me pide el alumno
    if($objeto->tabla === "alumno" && isset($objeto->nombre)){
        // Consultamos alumnos
        $sql = "SELECT * FROM alumnos WHERE alumno = ?";
        $resultado = $conexion->prepare($sql);
        $resultado->bind_param("s", $objeto->nombre);
        $resultado->execute();
        $stmt = $resultado->get_result();
        echo json_encode($stmt->fetch_all(MYSQLI_ASSOC));
        $resultado->close();
    } else if ($objeto->tabla === "direccion" && isset($objeto->idAlumno)){
        // Comprobamos si me pide la direccion
        $sql = "SELECT * FROM direccion WHERE idAlumno = ?";
        $resultado = $conexion->prepare($sql);
        $resultado->bind_param("i", $objeto->idAlumno);
        $resultado->execute();
        $stmt = $resultado->get_result();
        echo json_encode($stmt->fetch_all(MYSQLI_ASSOC));
        $resultado->close();
    
    } else{
        echo json_encode(["error" => "No se ha enviado el objeto correcto", "datos recibidos" => $objeto]);
    }
}