$(function(){
   obtenerPersonajes();
   mostrarHistorial();
   let nVictorias = 0;
})

function mostrarHistorial(){
    // Pido por get el historial para mostrar el historiald e partidas
    axios.get("php/get_historial.php")
    .then(function(response){
        // Obtengo la tabla
        let tabla = $("#tablaHistorial");
        //Recorro la respuesta y meto las filas en l tabla
        $.each(response.data, function(clave, valor){
            let fila = "<tr><td></td><td>" + valor.personaje1 + "</td><td>" + valor.personaje2 + "</td><td>" + valor.resultado + "</td> <td>" + valor.fecha +"</td><td>No</td></tr>";
            tabla.append(fila);
        })
    })
}

function obtenerPersonajes(){
    // Creo un conjunto para tener los planetas sin duplicar
    let conjuntoPlanetas = new Set();
    // Hago la peticion con jquery
    $.get("php/get_personajes.php").then(function(response){
        // Hago un split por los : para tener un array
         let array = response.split(":");
         let contador = 0;
         // Recorro el array y se que en la posicion 3 siempre estan los planetas
         $.each(array, function(clave, valor){
            // Si la posicion es 3 vuelvo ha hacer un split pero ahora por la coma y reseteo el contador, si no el contador lo incremento
            if (contador === 3 ){
                conjuntoPlanetas.add(valor.split(",")[0]);
                contador = 0;
            } else{
                contador ++
            }
         })
         // Recorro el conjunto limpio los datos y creo las opciones del select
         conjuntoPlanetas.forEach(valor=>{
            let value = valor.split('"')[1];
            let opcion = "<option value='" + value+ "'>" + value + "</option>";
            $("#planeta").append(opcion);
         });
    })

    // Añado un evento para habilitar el segundo select
    $("#planeta").on("change", habilitarBoton);
}

function habilitarBoton (){
    // Si ha puesto algo en el slect empiezo a pedir los personajes
    let value = $("#planeta").children(":selected").val();
    if (value != ""){

        // Vuelvo ha hacer la peticion y ahora me quedo con los personajes
        let personajes = [];
        // Hago la peticion con jquery
        $.get("php/get_personajes.php").then(function(response){
            // Esta peticion es la misma que la anterior
            let array = response.split(":");
            let contador = 0;
            // Pero ahora se que los personajes estan en la posicion 2
            $.each(array, function(clave, valor){
                if (contador == 2 ){
                    personajes.push(valor.split(",")[0]);
                } else if (contador == 3){
                    contador = 0;
                } else{
                    contador ++;
                }
            })
            // Creo otro array para poder limpiar los datos
            let personajesFinal = [];
            contador = 0;
            personajes.forEach((indice)=>{
                if (contador == 0){
                    personajesFinal.push(indice);
                    contador = 1;
                } else if(contador == 4){
                    personajesFinal.push(indice);
                    contador = 1;
                } else{
                    contador++;
                }
            })

            // Por ultimo recorro y termino de sanear los datos para mostrarlos en el select
            personajesFinal.forEach((valor) =>{
                let nvalor = valor.split('"')[1];
                let opcion = "<option value='" + nvalor.toLowerCase()+ ".webp'>" + nvalor + "</option>";
                $("#personaje").append(opcion);
            })

        })
        $("#personaje").prop("disabled", false);
        // Creo un evento para que cuendo elija un personaje me desabilite el boton de comfirmar y me añada un evento
        $("#personaje").on("change", empezarCombate);
    }
}

function empezarCombate(){
    $("#confirmarPersonaje").prop("disabled", false);
    // Añado el evento que lanzara la batalla
    $("#confirmarPersonaje").on("click", comenzarBatalla);
}

function comenzarBatalla(){
    // Oculto el frmulario y visibilizo la arena
    $("#seleccionPersonaje").css("display", "none");
    $("#arena").css("display", "block");
    $("#seccionJuego").css("display", "block");

    // Obtengo el valor del personaje y el del oponente
    let select = $("#personaje").children(":selected").val().toLowerCase();
    let nombre = $("#personaje").children(":selected").text();
    $("#jugador1").html(nombre);
    $("#imgJugador1").prop("src", "img/" +select);



    $("#jugador2").html("Goku");
    $("#imgJugador2").prop("src", "img/goku.webp");

    // Parte de lógica del piedra papel o tijera añadiendo el evento click y llamo a elegir
    $("#piedra").on("click", () => {
        $("#piedra").toggleClass("selected");
        elegir();
        $("#piedra").toggleClass("selected");
    });
    $("#papel").on("click", () => {
        $("#papel").toggleClass("selected");
        elegir();
        $("#papel").toggleClass("selected");
    });
    $("#tijera").on("click", () => {
        $("#tijera").toggleClass("selected");
        elegir();
        $("#tijera").toggleClass("selected");
    });
}

function elegir(){
    // Obtengo la que tiene la clase seleccionados
    let seleccionados = $(".selected");
    
    $("#eleccionJugador").html(seleccionados.html());
    // SAco un valor aleatorio

    let arrayValores = ["✂", "📜", "🪨"];
    let numero = 0;
    do{
        // Obtengo un numero aleatorio 
        numero = Math.round(Math.random() * 10);
    } while (numero > 3 || numero < 0);
    let oponente = arrayValores[numero];

    // Compruebo lo que ha sacado cada uno y hago un alert
    $("#eleccionMaquina").html(oponente);

    // Si empatan muestro un alert
    // Si gana el usuario cambio el marcador
    // Si gana la maquina cambio el marcador
    if ( $("#eleccionJugador").html() == $("#eleccionMaquina").html()){
        alert("Emapte");
    } else if($("#eleccionJugador").html() == "📜"){
        if ($("#eleccionMaquina").html() == "🪨"){
            let marcador = $("#marcador").html();
            if (marcador[0] == 0){
                $("#marcador").html("1 - " + marcador[4]);
            } else if (marcador[0] == 0){
                $("#marcador").html("2 - " + marcador[4]);
            }
        } else{
            let marcador = $("#marcador").html();
            if (marcador[4] == 0){
                $("#marcador").html(marcador[0] + " - 1");
            } else  if (marcador[4] == 1){
                $("#marcador").html(marcador[0] + " - 2");
            }
        }
    } else if ($("#eleccionJugador").html() == "🪨"){
        if ($("#eleccionMaquina").html() == "📜"){
            let marcador = $("#marcador").html();
            if (marcador[4] == 0){
                $("#marcador").html(marcador[0] + " - 1");
            } else  if (marcador[4] == 1){
                $("#marcador").html(marcador[0] + " - 2");
            }
        } else{
            let marcador = $("#marcador").html();
            if (marcador[0] == 0){
                $("#marcador").html("1 - " + marcador[4]);
            } else if (marcador[0] == 0){
                $("#marcador").html("2 - " + marcador[4]);
            }
        }
    } else if ($("#eleccionJugador").html() == "✂"){
        if ($("#eleccionMaquina").html() == "📜"){
            let marcador = $("#marcador").html();
            if (marcador[0] == 0){
                $("#marcador").html("1 - " + marcador[4]);
            } else if (marcador[0] == 0){
                $("#marcador").html("2 - " + marcador[4]);
            }
        } else{
            let marcador = $("#marcador").html();
            if (marcador[4] == 0){
                $("#marcador").html(marcador[0] + " - 1");
            } else  if (marcador[4] == 1){
                $("#marcador").html(marcador[0] + " - 2");
            }
        }
    }

    // Compruebo si ya ha ganado 1
    let marcador = $("#marcador").html();
    // Si ha ganado el usuario y persisto los datos en la base de datos
    if (marcador[0] == 2){
        swal.fire({
            text: "Ha ganado el jugador",
            icon: "success",
            })
        $("#imgJugador2").fadeOut(3000);
        $("#piedra").prop("disabled", true);
        $("#papel").prop("disabled", true);
        $("#tijera").prop("disabled", true);
        meterInfoCombate("jugador");
    } else if (marcador[4] == 2){ // Si ha ganado el oponente y persisto los datos en la base de datos
        swal.fire({
            text: "Ha ganado el oponente",
            icon: "success",
            });
        $("#imgJugador1").fadeOut(3000);
        $("#piedra").prop("disabled", true);
        $("#papel").prop("disabled", true);
        $("#tijera").prop("disabled", true);
        meterInfoCombate("oponente");
    }
}

function meterInfoCombate(ganador){
    // Obtengo los dos personajes
    let personaje1 = $("#jugador1").text();
    let personaje2 = $("#jugador2").text();
    // Miro quien ha ganado
    if(ganador == "oponente"){
        ganador = personaje2;
    } else{
        ganador = personaje1;
    }
    // Mediante axios meto los valores en la base de datos
    axios.post("php/guardar_combate.php", new URLSearchParams({
        personaje1: personaje1,
        personaje2: personaje2,
        resultado: ganador
    }))
    .then(function (response) {
        console.log(response);
    })
    .catch(function (error) {
        // Si hay un error, lo mostramos por consola
        console.error(error);
    });
}