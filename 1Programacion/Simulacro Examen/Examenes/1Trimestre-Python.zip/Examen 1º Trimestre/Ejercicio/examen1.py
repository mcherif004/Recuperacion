from examen1_lib import *
listado = ["casa", "salida", "marca", "listados", "sal", "ordenador", "dificultad", "media", "agua"]

print(menu(listado))
